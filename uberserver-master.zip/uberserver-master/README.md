# uberserver

Hello everyone, this is a Uber-like application I created, server side. It has some features from the original one, like:

- Login for users
- Sign up for users
- Login for drivers
- Signup for drivers
- Track nearby ubers/drivers
- Track nearby Uber petitions
- And everything needed for the driver and user app to function correctly

Of course it is not completed and has some bugs, so any recommendation is welcomed :)

For deploying the server, you'll need:
- Python (3.4.2) 
- Django (1.7)
- Django Rest Framework http://www.django-rest-framework.org/

You can also add any functions to the API as you need them.

Don't forget to put the server IP on the driver and user app.
